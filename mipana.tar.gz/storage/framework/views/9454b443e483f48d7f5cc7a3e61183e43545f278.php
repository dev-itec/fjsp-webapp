
<?php /**PATH /home/juanpab1o/Documentos/repos/fjsp-webapp/resources/views/components/plugins/fixed-plugin.blade.php ENDPATH**/ ?>