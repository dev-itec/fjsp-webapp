<section>
    <div class="page-header section-height-75 background bg-purple bg-gradient">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-8 d-flex flex-column mx-auto">
                    <div class="card card-plain mt-2">
                        <div class="card card-plain mt-6">
                            <img class="align-content-sm-center" src="<?php echo e(asset('assets/img/logo-app.png')); ?>" alt="">
                        </div>
                        
                        <div class="card-body pt-5">
                            <div class="col-12 me-auto px-0">
                                <a class="btn btn-light btn-lg w-100" href="#">
                                    <?php echo e(__('MIGRANTES')); ?>

                                </a>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="col-12 me-auto px-0">
                                <a class="btn btn-light btn-lg w-100" href="#">
                                    <?php echo e(__('ORGANIZACIONES')); ?>

                                </a>
                            </div>
                        </div>
                        <div class="card-footer text-light text-center pt-0 px-lg-2 px-1">
                            <small class="text-muted"><?php echo e(__('Recuperar contraseña')); ?> <a
                                    href="#"
                                    class="text-info text-gradient font-weight-bold"><?php echo e(__('aquí')); ?></a></small>
                            <p class="mb-4 text-light text-sm mx-auto">
                                <?php echo e(__(' Registrate')); ?>

                                <a href="#"
                                    class="text-info text-gradient font-weight-bold"><?php echo e(__('aquí')); ?></a>
                            </p>
                        </div>
                        
                
    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/juanpab1o/Documentos/repos/fjsp-webapp/resources/views/livewire/auth/login.blade.php ENDPATH**/ ?>