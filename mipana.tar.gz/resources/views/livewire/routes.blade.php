<div>
    <x-mig.routes></x-mig.routes>
</div>

