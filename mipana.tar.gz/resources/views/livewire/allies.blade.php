<div>
    <div class="alert alert-neutral mx-0" role="alert">
        <span class="text-white d-flex justify-content-end">
            <button class="btn btn-icon btn-3 btn-primary " type="button">
                <span class="btn-inner--icon">
                    <i class="fas fa-plus"></i>
                </span>
                <span class="btn-inner--text">Crear Alianza</span>
            </button>
        </span>
    </div>
    <x-ngos.allies></x-ngos.allies>
</div>
