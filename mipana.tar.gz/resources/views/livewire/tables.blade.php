    <main>
      <div class="container-fluid py-4">
       {{-- Tables --}}
        @include('components.tables.table')
      </div>
    </main>
