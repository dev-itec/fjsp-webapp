<div>
    <div class="alert alert-neutral mx-0" role="alert">
        <span class="text-white d-flex justify-content-end">
            <button class="btn btn-icon btn-3 btn-primary " type="button">
                <span class="btn-inner--icon">
                    <i class="fa fa-download"></i>
                </span>
                <span class="btn-inner--text">Descargar formato</span>
            </button>
            &nbsp;
            <button class="btn btn-icon btn-3 btn-primary " type="button">
                <span class="btn-inner--icon">
                    <i class="fa fa-upload"></i>
                </span>
                <span class="btn-inner--text">Subir archivo</span>
            </button>
        </span>
    </div>
</div>
