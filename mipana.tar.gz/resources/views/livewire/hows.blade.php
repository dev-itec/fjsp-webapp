<div>
    <iframe src="http://localhost:8000/chatify" class="w-100 vh-100 d-inline-block"></iframe>
</div>
