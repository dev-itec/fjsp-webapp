<div>
    <x-ngos.events></x-ngos.events>
</div>
